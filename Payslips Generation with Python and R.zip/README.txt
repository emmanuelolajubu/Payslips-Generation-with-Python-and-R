Description

This project highlights how to dynamically generate names and payslips for workers in an organization. The project was made with Python and converted to R.

I used the Faker library and Random module to generate names and payslips in the Python framework and specified the condition statements. The code was eventually converted to R.

Contributing
I'd appreciate any contributions! Here are some ways you can get started:

1. Report bugs: If you encounter any bugs, please let me know. Open up an issue and let me know the problem.
2. Contribute code: If you are a developer and want to contribute, follow the instructions below to get started!
3. Suggestions: If you don't want to code but have some awesome ideas, open up an issue explaining some updates or improvements you would like to see!
4. Documentation: If you see the need for some additional documentation, feel free to add some!


Instructions
1. Fork this repository
2. Clone the forked repository
3. Add your contributions (code or documentation)
4. Commit and push
5. Create a pull request
6. Star this repository
7. Wait for the pull request to be merged.